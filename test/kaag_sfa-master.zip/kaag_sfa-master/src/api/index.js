import * as axios from 'axios'
import { versions, apiUrl } from '../utils/constants'

export function login ({ username, password, tabletPassword }) {
  return axios.post(apiUrl, {
    flid: '',
    md: '0',
    ss: '',
    uid: username,
    obj: {
      ...versions,
      revision: '0',
      userId: username,
      passWd: password
    }
  })
  .then(response => {
    // 第一段階ログイン成功時
    if (response.data.value.sessionId) {
      return axios.post(apiUrl, {
        flid: '',
        md: '200100',
        ss: response.data.value.sessionId,
        uid: username,
        obj: {
          ...versions,
          revision: '0',
          userId: username,
          passWd: tabletPassword
        }
      })
    } else {
      return Promise.resolve(response)
    }
  })
  .then(response => {
    return Promise.resolve(getLoginResponse(response.data))
  })
  .catch(error => {
    console.log(error)
  })
}

function getLoginResponse (data) {
  return {
    sessionId: data.value.sessionId,
    message: data.value.mess
  }
}
