<template>
  <table id="data_table" class="column16p">
    <thead>
      <tr>
        <th>区分</th>
        <th>代理店<br>コード</th>
        <th>代理店・扱者名</th>
        <th>潜在収保（万円）</th>
        <th>シナリオ</th>
        <th>最終活動日</th>
        <th>活動内容</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
      <tr>
        <td>●●</td>
        <td>●●●</td>
        <td>●●●●●●</td>
        <td><input type="text" class="input_text" value=""></td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
        <td>●●●●●●</td>
      </tr>
    </tbody>
  </table><!--/data_table-->
</template>
