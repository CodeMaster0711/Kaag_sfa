export const versions = {
  devVersion: '1',
  majorVersion: '4',
  minorVersion: '2'
}

export const apiUrl = 'http://dev.aioindi-sfa.jp/adsfa2tablet/tabletindex.php'
export const apiMultiUrl = 'http://dev.aioindi-sfa.jp/adsfa2tablet/tabletindex.php'
