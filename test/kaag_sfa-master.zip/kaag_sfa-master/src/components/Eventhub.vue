export default new Vue()
